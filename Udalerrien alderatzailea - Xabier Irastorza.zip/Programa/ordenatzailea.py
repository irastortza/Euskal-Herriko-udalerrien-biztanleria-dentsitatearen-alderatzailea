#ZEHAZTAPENA
#Aurre: Fitxategi bat, herri abkoitzaren antzekoak '&' sinboloaz bereiziak eta herriak '//' sinboloaz bereiziak dituena.
#Post: Fitxategi bat, zeinaren herri-izen guztiak 8 karakteretara laburtuta dauden (handiagoak puntu
#batez moztuak).
f = open ("emaitzak_ordenatuta.txt","r");
irakur=f.read ()
f.close ()
kont=1;
irakur2=""
for i in range (0,len(irakur)):
    if irakur[i] == "\n":
        irakur2=irakur2+" /"+"hline"
    if irakur[i] == "&" or irakur[i] == "\n" or irakur[i] == "/":
        kont=0;
        irakur2=irakur2+irakur[i]
    elif kont < 8:
        irakur2=irakur2+irakur[i]
    elif kont == 8:
        if irakur[i+1] != "&" and irakur[i+1] != "/":
            irakur2=irakur2+".";
        else:
            irakur2=irakur2+irakur[i];
    kont=kont+1;
f = open ("emaitzak_ordenatuta2.txt","w");
f.write (irakur2);
f.close ();
    
    
